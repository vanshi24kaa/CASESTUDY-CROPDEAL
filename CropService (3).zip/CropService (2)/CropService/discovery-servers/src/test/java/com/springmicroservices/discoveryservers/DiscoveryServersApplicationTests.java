package com.springmicroservices.discoveryservers;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DiscoveryServersApplicationTests {

	@Test
	void contextLoads() {
	}

}
