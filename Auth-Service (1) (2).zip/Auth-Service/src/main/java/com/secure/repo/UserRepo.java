package com.secure.repo;

import java.util.Optional;

import org.springframework.data.mongodb.repository.MongoRepository;


import org.springframework.stereotype.Repository;

import com.secure.entity.User;
@Repository
public interface UserRepo  extends MongoRepository<User, Integer>
{
	Optional<User> findByUserName(String userName);
     
}
