package com.cropdeal.farmerservice.model;

public class Buyer {
	private String buyername;
	private String buyercontactNo;
	
	
	public Buyer(String buyername, String buyercontactNo) {
		super();
		this.buyername = buyername;
		this.buyercontactNo = buyercontactNo;
	}


	public Buyer() {
		super();
		// TODO Auto-generated constructor stub
	}


	public String getBuyername() {
		return buyername;
	}


	public void setBuyername(String buyername) {
		this.buyername = buyername;
	}


	public String getBuyercontactNo() {
		return buyercontactNo;
	}


	public void setBuyercontactNo(String buyercontactNo) {
		this.buyercontactNo = buyercontactNo;
	}
	
	
	
}
